package com.example.gui.exercicio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editarTexto = findViewById(R.id.editarTexto);
        Button botao = findViewById(R.id.botao);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(editarTexto.getText().length() != 0) {
                   Toast.makeText(MainActivity.this, editarTexto.getText(), Toast.LENGTH_SHORT).show();
               }
               else{
                   Toast.makeText(MainActivity.this, "Voce nao digitou nada!", Toast.LENGTH_SHORT).show();
                   Log.e("editarTexto", "Error");
               }
           }
        }
        );
    }
}

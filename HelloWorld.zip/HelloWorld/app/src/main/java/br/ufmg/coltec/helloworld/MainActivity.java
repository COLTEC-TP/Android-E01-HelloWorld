package br.ufmg.coltec.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText text = findViewById(R.id.texto); //declarando texto
        Button botão = findViewById(R.id.botao); //declarando botao

        botão.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mensagem = text.getText().toString(); //declarando string
                if(mensagem.equals("")){
                    Log.e("null","ERRO"); //função de erro
                    //erro
                }else{
                    Toast toast = Toast.makeText(MainActivity.this, mensagem, 2);
                    toast.show();
                    //mostrar mensagem
                }
            }
        });

    }

    }

